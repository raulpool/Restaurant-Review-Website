<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Auth::routes();

Route::get('/', function () { // this takes me to the usual laravel page
    return view('welcome');
    //return view('pages.cart.additem');
    //return view('layouts.master');
}); 

Route::post('home', function () {
     return view('home');
}); 

Route::get('password', function () {
     return view('auth.password');
});
Route::post('password', function () {
     return view('auth.password');
});

Route::get('user', 'UserController@orderSubmitted');

Route::get('seeusers', 'UserController@getusers');

Route::get('changestatustoadmin/{id}', 'UserController@changestatustoadmin');
Route::get('changestatustoregular/{id}', 'UserController@changestatustoregular');

Route::get('myreviews' ,'ReviewController@myreviews');

Route::get('myreviewscont' ,'ReviewController@myreviewscont');

Route::get('restaurantlist', 'RestaurantController@getRestaurants');

Route::get('createrestaurant', function () {
     return view('auth.createrestaurant');
});

Route::post('createrestaurant', 'RestaurantController@addRestaurant');

/*Route::get('addreview/{id}', function () {
     return view('auth.addreview');
});*/

Route::get('addreview/{id}', 'ReviewController@addRev');

Route::get('addreview', function () {
     return view('auth.addreview');
});

//Route::get('addreview/{id}', 'ReviewController@addreview');

Route::post('addreview', 'ReviewController@addreview');
/* Route::post('createrestaurant', function () {
     return view('auth.createrestaurant');
}); */

Route::get('menulist', 'MenuController@getMenu');

Route::post('cart/additem', 'UserController@addItemToCart');
// Route::delete() responds to the HTTP DELETE method
Route::get('user/{id}', function($userId)
{
   return "This route would delete the user with the ID of ${userId} ";
   //return view('welcome'); // this allows me to use html and display stuff here on the blade page 
	//return view('cart.additem'); // this makes it so searches pages/cart/ additem.php
});


Route::get('restaurant/{id}', 'RestaurantController@viewResDetails');

Route::get('test', 'UserController@addItemToCart');





/*
Route::get('restaurant/{id}', function($userId)
{
   return "This route should show the details for restaurant with the ID of ${userId}";
}); 
*/

/* 
the following was a test I did to check my page. Basically this won't work because the restaraunt page
is dependant on a variable called data being passed by another function. Since the variable doesnt go through it won't work 
Route::get('restaurant', function () {
     return view('pages.cart.restaurant');
});
*/

// first paramete is a string that is the url, second is function or array 
/* Route::get('/', function() 
{ // Route::get() responds to the HTTP GET method and this shows me the message on the screen
   return "Welcome to the landing page!?";
}); */
// tell array what to use
//Route::get('users',array('uses' => 'users@index'));


// dont need a closing php tag