@extends('app')

@section('content')
{!! Form::open(['url' => url('myreviewscont')]) !!}
   <h1>Enter your user id, the number not your username</h1>
   <br>
   {!! Form::text('userid') !!}

<div class="btn-group">
    <a href="/project4/public/myreviewscont" class="btn btn-primary">
        <i class="fa fa-cog" aria-hidden="false"></i> Take to me my reviews
    </a>
</div>


{!! Form::close() !!}

@endsection