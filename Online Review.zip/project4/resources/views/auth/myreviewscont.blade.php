@extends('app')

@section('content')
@foreach ($review as $got)
	@if($got->u_id == $userid)
   <h1>Reviews for {{$got->name}}</h1>
   <br>

<div class="btn-group">
    <a href="/project4/public/myreviewscont" class="btn btn-primary">
        <i class="fa fa-cog" aria-hidden="false"></i> Take me my reviews
    </a>
</div>
	@else
	<p>You don't have any reviews</p>

@endif

@endforeach


@endsection