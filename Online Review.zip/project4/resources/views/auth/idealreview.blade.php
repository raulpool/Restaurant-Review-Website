@extends('app')

@section('content')
<div class="container-fluid">
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-default">
				<div class="panel-heading">Add Review</div>
				<div class="panel-body">
					@if (count($errors) > 0)
						<div class="alert alert-danger">
							<strong>Whoops!</strong> There were some problems with your input.<br><br>
							<ul>
								@foreach ($errors->all() as $error)
									<li>{{ $error }}</li>
								@endforeach
							</ul>
						</div>
					@endif

		{!! Form::open(['url' => url('addreview')]) !!}

						<div class="form-group">
							<label class="col-md-4 control-label">Enter {{$id}} for the ID of the restaurant</label>
							<div class="col-md-6">
								{!! Form::text('rid') !!}
							</div>
						</div>


						<div class="form-group">
							<label class="col-md-4 control-label">Rating(1-5)</label>
							<div class="col-md-6">
								{!! Form::text('rating') !!}
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">Review</label>
							<div class="col-md-6">
								{!! Form::textarea('review') !!}
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">Rating headline</label>
							<div class="col-md-6">
								{!! Form::text('Headline') !!}
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">Please enter your user id to proceed </label>
							<div class="col-md-6">
								{!! Form::text('u_id') !!}
							</div>
						</div>

					{!! Form::submit('Add Review') !!}

			{!! Form::close() !!}
				</div>
			</div>
		</div>
	</div>
</div>
@endsection
