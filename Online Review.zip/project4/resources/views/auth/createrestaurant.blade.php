@extends('app')

@section('content')
<div class="container-fluid">
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-default">
				<div class="panel-heading">Add Restaurant</div>
				<div class="panel-body">
					@if (count($errors) > 0)
						<div class="alert alert-danger">
							<strong>Whoops!</strong> There were some problems with your input.<br><br>
							<ul>
								@foreach ($errors->all() as $error)
									<li>{{ $error }}</li>
								@endforeach
							</ul>
						</div>
					@endif

{!! Form::open(['url' => url('createrestaurant')]) !!}



						<div class="form-group">
							<label class="col-md-4 control-label">Name</label>
							<div class="col-md-6">
								{!! Form::text('name') !!}
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">Address</label>
							<div class="col-md-6">
								{!! Form::text('address') !!}
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">City</label>
							<div class="col-md-6">
								{!! Form::text('city') !!}
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">State</label>
							<div class="col-md-6">
								{!! Form::text('state') !!}
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">Zip</label>
							<div class="col-md-6">
								{!! Form::text('zip') !!}
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">Average Rating(Optional)</label>
							<div class="col-md-6">
								{!! Form::text('avgrating') !!}
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">Website(Optional)</label>
							<div class="col-md-6">
								{!! Form::text('website') !!}
							</div>
						</div>

					{!! Form::submit('Add Restaurant') !!}

			{!! Form::close() !!}
				</div>
			</div>
		</div>
	</div>
</div>
@endsection
