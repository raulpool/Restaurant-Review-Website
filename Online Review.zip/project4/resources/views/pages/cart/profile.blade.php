@extends('app')

@section('content')
   <h1>My Profile</h1>

@foreach ($user as $got)
   <strong> Username</strong>
   <br>
   <p>{{$got->email}}</p>
   <strong>Name Given at Registration</strong> 
   <p>{{$got->name}}</p>
   <br>
   <strong>Email</strong> 
   <p>{{$got -> email}}</p>
   <br>
   <strong>Registration Date</strong>
   <p>{{$got -> created_at}}</p>
   <br>
@endforeach

@endsection