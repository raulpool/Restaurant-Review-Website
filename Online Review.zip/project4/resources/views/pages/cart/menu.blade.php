@extends('app')

@section('content')
   <h1>Menu of all restaurants</h1>

@foreach ($menu as $got)
	@if ($got -> rid == 1)
   <h4> {{$got->item_name}} Big Load For Matt </h4>
   <br>
   <strong>Price: </strong> <p> $ {{$got->price}}</p>
   <br>
   <strong>Description: </strong> <p> {{$got -> description}}</p>
   <br>
   @endif
@endforeach

@endsection