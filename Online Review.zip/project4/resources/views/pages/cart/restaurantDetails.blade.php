@extends('app')

@section('content')
   <h1>Restaurant details for {{$id}} </h1>

<div class="btn-group">
    <a href="/project4/public/addreview/{{$id}}" class="btn btn-primary">
        <i class="fa fa-cog" aria-hidden="false"></i> Add Review
    </a>
</div>

@foreach ($data as $got)
	@if($got -> rid == $id )
		<h2>Restautant Information for {{$got->name}}</h2>
   		<h3>Address: </h3>
   		<p>{{$got->address}}</p>
   		<p> {{$got -> city}}, {{$got->state}} {{$got->zip}} </p>
   		<h3>Website</h3>
   		<br>
   		<a href = 'restaurant/{{$got->rid}}'> {{$got -> website}} </a>
   		<br>
   		<h3> Buisness Hours</h3>
   		@if($got->daysopen == NULL)
   			<p>No avialable inforation. Contact owner</p>
   		@else
   			<p> {{$got->daysopen}} </p>
   			<p> {{$got->openhour}} - {{$got->closehour}} </p>
   		@endif

   		<h3> Menu </h3>
   		@foreach ($menu as $info)
   			@if ($info -> rid == $id)
	   			<p> {{$info ->item_name}} </p>
   				<strong>Price: </strong>
   				<p> $ {{$info->price}}</p>
   				<strong>Description: </strong> <p> {{$info -> description}}</p>
   			@endif
		@endforeach
		<h3> Reviews </h3>
   		@foreach ($review as $reviews)
   			@if ($reviews -> rid == $id)
   				<strong> Number of Stars Given </strong>
   				<p> {{$reviews -> rating}} </p>
	   			<strong> {{$reviews -> item_name}} </strong>  
   				<p> {{$reviews->review}}</p>
   				<br>
   			@endif
		@endforeach


   @endif
@endforeach

@endsection