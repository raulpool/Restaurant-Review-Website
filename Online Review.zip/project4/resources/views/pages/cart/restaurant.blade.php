@extends('app')

@section('content')
   <h1>List of restaurants</h1>

@foreach ($data as $got)
   <h4> {{$got->name}}</h4>
   <p>Located at:</p> <p> {{$got->address}} {{$got -> city}}, {{$got->state}} </p>
   <a href = 'restaurant/{{$got->rid}}' > Restaurant Details </a>
@endforeach

@endsection