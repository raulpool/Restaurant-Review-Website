@extends('app')

@section('content')
   <h1>List of users and their roles</h1>

@foreach ($data as $got)
 	<strong>Name Given at Registration</strong> 
   <p>{{$got->name}}</p>
   <strong>Email</strong>
   <br>
   <p>{{$got->email}}</p>
   <strong>Registration Date</strong>
   <p>{{$got -> created_at}}</p>
   <strong>Role</strong>
   <br>
   @if($got->role == 2)
   	Admin
   	<div class="btn-group">
    <a href="/project4/public/changestatustoregular/{{$got->id}}" class="btn btn-danger">
        <i class="fa fa-cog" aria-hidden="false"></i> Demote to pleb
    </a>
    </div>
    <br>
   @else
   	Regular
   	<div class="btn-group">
    <a href="/project4/public/changestatustoadmin/{{$got->id}}" class="btn btn-success">
        <i class="fa fa-cog" aria-hidden="false"></i> Upgrade to Admin
    </a>
	</div>
   <br>
   @endif
@endforeach

@endsection