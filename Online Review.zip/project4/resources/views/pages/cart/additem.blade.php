@extends('layouts.master')

@section('content')
   <p>You can add an item to your cart on this page</p>

<div class="btn-group">
    <a href="/project4/public/restaurantlist" class="btn btn-primary">
        <i class="fa fa-cog" aria-hidden="false"></i> Take me to the stores
    </a>
</div>

{!! Form::open(['url' => url('cart/additem')]) !!}

{!! Form::text('username') !!}
{!! Form::password('password') !!}
{!! Form::textarea('comments') !!}
{!! Form::select('choice', ['one' => 'Choice One', 'two' => 'Choice Two']) !!}
{!! Form::submit('Submit Form') !!}

{!! Form::close() !!}

@for($i = 0; $i < 10; $i++)
   <p>This is iteration {{ $i }} of the loop</p>
@endfor

@endsection
