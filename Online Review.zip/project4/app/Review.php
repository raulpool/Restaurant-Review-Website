<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Review extends Model
{
    //
    protected $fillable = [
        'rid', 'u_id', 'item_name', 'review', 'rating',
    ];
}
