<?php
namespace App\Http\Controllers; // remember these?
use App\Http\Controllers\Controller;
use Illuminate\Http\Request; // place after namespace but before the class definition
use App\User;
use DB;
use Auth;

class UserController extends Controller {
   // methods for the controller go in the class body
   // only PUBLIC methods should be wired to routes
	public function display() 
	{
   		return "This route displays the shopping cart for the current logged-in user";
	}
	public function addItemToCart(Request $request) 
	{
   // retrieve submitted POST data and add the item ID to the cart
		$item = $request->input('password'); // input() returns data from the request
      	//return "You entered ${item} in the box";

      	$allUsers = User::all();
      	//$test = User::id();
      	$user = Auth::user();
		if ($user)
		{
   			 echo "Hello $user->name";
		}
		//return $allUsers;
		//return $test;

	}
	public function orderSubmitted() 
	{
  		return redirect('/'); // okay this redirect works but no message lol
	}

	public function getUsers()
	{

    	$get = DB::table('users')->get();

    	return view('pages.cart.seeusers', ['data' => $get]);
	}

	public function changestatustoadmin($id)
	{

		DB::table('users')->where('id', $id)->update(['role' => 2]);
    	$data = DB::table('users')->get();

    	return view('pages.cart.seeusers', ['id' => $id,'data' => $data]);
	}

	public function changestatustoregular($id)
	{

		DB::table('users')->where('id', $id)->update(['role' => 1]);
    	$data = DB::table('users')->get();

    	return view('pages.cart.seeusers', ['id' => $id,'data' => $data]);
	}
}