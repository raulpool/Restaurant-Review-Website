<?php
public function viewOrder($id) {
   return "This route displays the information for order number ${id}";
}