<?php

namespace App\Http\Controllers;
//namespace App\Http\Controllers\Auth;

use Auth;
use App\Restaurant;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
//use Illuminate\Foundation\RegistersRestaurants;
use Illuminate\Http\Request;
use DB;

class RestaurantController extends Controller
{
    //
     
    public function getRestaurants()
	{

    	$get = DB::table('restaurants')->get();

    	return view('pages.cart.restaurant', ['data' => $get]);
	}

	public function viewResDetails($id) {
   		//return "This route displays the information for order number ${id}";
   		$details = DB::table('restaurants')->get();
   		$data = DB::table('menus')->get();
   		$reviews = DB::table('reviews')->get();

    	return view('pages.cart.restaurantDetails', ['data' => $details, 'id' => $id, 'menu' => $data, 'review' => $reviews]);
	}


	public function addRestaurant(Request $request) 
	{
   // retrieve submitted POST data and add the item ID to the cart
		$name = $request->input('name');
		$address = $request->input('address');
		$city = $request->input('city');
		$state = $request->input('state');
		$zip = $request->input('zip');
		$avgrating = $request->input('avgrating');
		$website = $request->input('website');
		//$item = $request->input('password'); // input() returns data from the request
      	//return "You entered ${name} in the box";
      	 Restaurant::create(["name" => "${name}", "address" => "${address}", "city" => "{$city}", "state" => $state, "zip" => $zip, "avgrating" => $avgrating, "website" => $website, "created_at" => date('Y-m-d H:m:s'), "updated_at" => date('Y-m-d H:m:s') ]); 

		$get = DB::table('restaurants')->get();

    	return view('pages.cart.restaurant', ['data' => $get]);

      	 //return view('pages.cart.restaurant');

      	/* $allUsers = User::all();
		return $allUsers; */

	}

}
