<?php

namespace App\Http\Controllers;
use Auth;
use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;

use Illuminate\Http\Request;
use DB;

class MenuController extends Controller
{
    //
    public function getMenu()
	{

    	$data = DB::table('menus')->get();

    	return view('pages.cart.menu', ['menu' => $data]);
	}
}
