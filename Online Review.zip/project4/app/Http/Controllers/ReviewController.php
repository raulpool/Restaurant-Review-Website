<?php

namespace App\Http\Controllers;

use Auth;
use App\Review;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;

class ReviewController extends Controller
{
    //

     public function addRev($id) 
	{
		$reviews = DB::table('reviews')->get();

		return view('auth.idealreview', ['id' => $id, 'review' => $reviews]);


	}
	public function myreviews() 
	{
		$reviews = DB::table('reviews')->get();

		return view('auth.myreviews', ['review' => $reviews]);
	}

	public function myreviewscont(Request $request) 
	{

		$userid = $request -> input('userid');
		$reviews = DB::table('reviews')->get();

		return view('auth.myreviewscont', ['userid' => $userid,'review' => $reviews]);
	}

    public function addreview(Request $request) 
	{
   // retrieve submitted POST data and add the item ID to the cart
		//$rid = 7; 
		$item_name = $request->input('Headline');
		//return $id;
		$rating = $request->input('rating');
		//$taglines = $request->input('tag');
		$review = $request->input('review');
		
		$rid = $request->input('rid');

		$u_id= $request->input('u_id');

		//return "{$tagline}";
	
      	 Review::create(["rid" => $rid, "u_id" => $u_id, "rating" => $rating, "item_name" => $item_name, "rating" => $rating, "review" => $review]); 

      	 //return "success added {$rating} {$item_name} {$review}";

		$get = DB::table('reviews')->get();

    	return view('auth.addreview');


	}
}
