<?php 
Route::delete('users/{id}', function($userId) {
   return "This route would delete the user with the ID of ${userId}";
});