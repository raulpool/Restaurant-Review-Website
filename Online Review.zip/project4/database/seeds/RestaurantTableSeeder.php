<?php

use Illuminate\Database\Seeder;
use App\Restaurant;

class RestaurantTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
      Restaurant::create(["name" => "Hot Buns Galore", "address" => "1995 W East St", "city" => "Los Angeles", "state" => "CA", "zip" => "90037", "avgrating" => "5", "website" => "www.youtube.com", "openhour" => "09:00 AM", "closehour" => "06:00 PM", "daysopen" => "Monday - Thursday", "created_at" => date('Y-m-d H:m:s'), "updated_at" => date('Y-m-d H:m:s'), ]);
   
    }
}
