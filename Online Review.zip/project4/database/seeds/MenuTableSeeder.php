<?php

use Illuminate\Database\Seeder;
use App\Menu;

class MenuTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
      Menu::create(["rid" => "1", "item_name" => "Hot Buns", "description" => "Lukewarm Buns", "price" => "12", "created_at" => date('Y-m-d H:m:s'), "updated_at" => date('Y-m-d H:m:s') ]);
      Menu::create(["rid" => "2", "item_name" => "Sticky Buns", "description" => "Cold Brewed Human", "price" => "4.20", "created_at" => date('Y-m-d H:m:s'), "updated_at" => date('Y-m-d H:m:s')]);
    }
}
