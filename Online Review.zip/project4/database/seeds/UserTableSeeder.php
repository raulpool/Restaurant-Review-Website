<?php

use Illuminate\Database\Seeder;
use App\User;

class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    // Seeders have only one method: run(). This method adds the data to a specific table. In our case, we’ll want to use the existing User model to populate user data.
    {
        //
      User::create(["role" => "2", "name" => "User A", "email" => "a@a.com", "password" => bcrypt("abc")]);
      User::create(["role" => "1","name" => "User B", "email" => "b@b.com", "password" => bcrypt("def")]);
    }
}
