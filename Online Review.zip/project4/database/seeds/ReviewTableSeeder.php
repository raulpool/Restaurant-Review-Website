<?php

use Illuminate\Database\Seeder;
use App\Review; // dont have this then the revew::create wont work

class ReviewTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        Review::create(["rid" => "1", "u_id" => "1", "item_name" => "Hot Buns", "Review" => "Buns so hot, make them beats weak", "Rating" => "5", ]);
    }
}
