<?php

use Illuminate\Database\Seeder;
use App\User;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	// In the DatabaseSeeder.php class, add a line in the run() method to execute your new seeder class:

//The call() method will find and execute the run() method in the seeder class specified.
       // $this->call(UsersTableSeeder::class);
        $this->call('UserTableSeeder');
        $this->call('MenuTableSeeder');
        $this->call('RestaurantTableSeeder');
        $this->call('ReviewTableSeeder');
    }
}
