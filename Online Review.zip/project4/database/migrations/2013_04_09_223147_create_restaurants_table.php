<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRestaurantsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //scheme::create
        Schema::create('restaurants', function (Blueprint $table) {
        $table->increments('rid'); // auto-incrementing integer ID and primary key
        $table->string('name');  //restaurant name
        $table->string('address'); // restaurant address
        $table->string('city'); // city
        $table->string('state');
        $table->integer('zip');
        $table->integer('avgrating')->nullable();;
        $table->string('website')->nullable();;
        $table->string('openhour')->nullable();;
        $table->string('closehour')->nullable();;
        $table->text('daysopen')->nullable();;
        $table->timestamp('created_at')->default(DB::raw('CURRENT_TIMESTAMP'));
        $table->timestamp('updated_at')->nullable(); // value can be NULL
    });//
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('restaurants');//
        //
    }
}
