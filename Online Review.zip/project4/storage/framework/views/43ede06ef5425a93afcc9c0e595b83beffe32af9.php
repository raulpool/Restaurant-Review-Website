<?php $__env->startSection('content'); ?>
   <h1>List of restaurants</h1>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $got): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <h4> <?php echo e($got->name); ?></h4>
   <p>Located at:</p> <p> <?php echo e($got->address); ?> <?php echo e($got -> city); ?>, <?php echo e($got->state); ?> </p>
   <a href = 'restaurant/<?php echo e($got->rid); ?>' > Restaurant Details </a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>