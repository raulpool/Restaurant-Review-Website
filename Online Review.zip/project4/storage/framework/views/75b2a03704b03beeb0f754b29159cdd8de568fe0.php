<?php $__env->startSection('content'); ?>
   <h1>My Profile</h1>

<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $got): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <strong> Username</strong>
   <br>
   <p><?php echo e($got->email); ?></p>
   <strong>Name Given at Registration</strong> 
   <p><?php echo e($got->name); ?></p>
   <br>
   <strong>Email</strong> 
   <p><?php echo e($got -> email); ?></p>
   <br>
   <strong>Registration Date</strong>
   <p><?php echo e($got -> created_at); ?></p>
   <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>