<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-default">
				<div class="panel-heading">Add Review</div>
				<div class="panel-body">
					<?php if(count($errors) > 0): ?>
						<div class="alert alert-danger">
							<strong>Whoops!</strong> There were some problems with your input.<br><br>
							<ul>
								<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li><?php echo e($error); ?></li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
					<?php endif; ?>

		<?php echo Form::open(['url' => url('addreview')]); ?>


						<div class="form-group">
							<label class="col-md-4 control-label">Enter <?php echo e($id); ?> for the ID of the restaurant</label>
							<div class="col-md-6">
								<?php echo Form::text('rid'); ?>

							</div>
						</div>


						<div class="form-group">
							<label class="col-md-4 control-label">Rating(1-5)</label>
							<div class="col-md-6">
								<?php echo Form::text('rating'); ?>

							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">Review</label>
							<div class="col-md-6">
								<?php echo Form::textarea('review'); ?>

							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">Rating headline</label>
							<div class="col-md-6">
								<?php echo Form::text('Headline'); ?>

							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">Please enter your user id to proceed </label>
							<div class="col-md-6">
								<?php echo Form::text('u_id'); ?>

							</div>
						</div>

					<?php echo Form::submit('Add Review'); ?>


			<?php echo Form::close(); ?>

				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>