<?php $__env->startSection('content'); ?>
<?php echo Form::open(['url' => url('myreviewscont')]); ?>

   <h1>Enter your user id, the number not your username</h1>
   <br>
   <?php echo Form::text('userid'); ?>


<div class="btn-group">
    <a href="/project4/public/myreviewscont" class="btn btn-primary">
        <i class="fa fa-cog" aria-hidden="false"></i> Take to me my reviews
    </a>
</div>


<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>