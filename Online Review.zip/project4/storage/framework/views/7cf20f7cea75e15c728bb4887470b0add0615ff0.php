<?php $__env->startSection('content'); ?>
   <h1>Restaurant details for <?php echo e($id); ?> </h1>

<div class="btn-group">
    <a href="/project4/public/addreview/<?php echo e($id); ?>" class="btn btn-primary">
        <i class="fa fa-cog" aria-hidden="false"></i> Add Review
    </a>
</div>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $got): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php if($got -> rid == $id ): ?>
		<h2>Restautant Information for <?php echo e($got->name); ?></h2>
   		<h3>Address: </h3>
   		<p><?php echo e($got->address); ?></p>
   		<p> <?php echo e($got -> city); ?>, <?php echo e($got->state); ?> <?php echo e($got->zip); ?> </p>
   		<h3>Website</h3>
   		<br>
   		<a href = 'restaurant/<?php echo e($got->rid); ?>'> <?php echo e($got -> website); ?> </a>
   		<br>
   		<h3> Buisness Hours</h3>
   		<?php if($got->daysopen == NULL): ?>
   			<p>No avialable inforation. Contact owner</p>
   		<?php else: ?>
   			<p> <?php echo e($got->daysopen); ?> </p>
   			<p> <?php echo e($got->openhour); ?> - <?php echo e($got->closehour); ?> </p>
   		<?php endif; ?>

   		<h3> Menu </h3>
   		<?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   			<?php if($info -> rid == $id): ?>
	   			<p> <?php echo e($info ->item_name); ?> </p>
   				<strong>Price: </strong>
   				<p> $ <?php echo e($info->price); ?></p>
   				<strong>Description: </strong> <p> <?php echo e($info -> description); ?></p>
   			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<h3> Reviews </h3>
   		<?php $__currentLoopData = $review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reviews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   			<?php if($reviews -> rid == $id): ?>
   				<strong> Number of Stars Given </strong>
   				<p> <?php echo e($reviews -> rating); ?> </p>
	   			<strong> <?php echo e($reviews -> item_name); ?> </strong>  
   				<p> <?php echo e($reviews->review); ?></p>
   				<br>
   			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


   <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>