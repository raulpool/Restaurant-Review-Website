<?php $__env->startSection('content'); ?>
   <h1>List of users and their roles</h1>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $got): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 	<strong>Name Given at Registration</strong> 
   <p><?php echo e($got->name); ?></p>
   <strong>Email</strong>
   <br>
   <p><?php echo e($got->email); ?></p>
   <strong>Registration Date</strong>
   <p><?php echo e($got -> created_at); ?></p>
   <strong>Role</strong>
   <br>
   <?php if($got->role == 2): ?>
   	Admin
   	<div class="btn-group">
    <a href="/project4/public/changestatustoregular/<?php echo e($got->id); ?>" class="btn btn-danger">
        <i class="fa fa-cog" aria-hidden="false"></i> Demote to pleb
    </a>
    </div>
    <br>
   <?php else: ?>
   	Regular
   	<div class="btn-group">
    <a href="/project4/public/changestatustoadmin/<?php echo e($got->id); ?>" class="btn btn-success">
        <i class="fa fa-cog" aria-hidden="false"></i> Upgrade to Admin
    </a>
	</div>
   <br>
   <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>