<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-default">
				<div class="panel-heading">Add Restaurant</div>
				<div class="panel-body">
					<?php if(count($errors) > 0): ?>
						<div class="alert alert-danger">
							<strong>Whoops!</strong> There were some problems with your input.<br><br>
							<ul>
								<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li><?php echo e($error); ?></li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
					<?php endif; ?>

<?php echo Form::open(['url' => url('createrestaurant')]); ?>




						<div class="form-group">
							<label class="col-md-4 control-label">Name</label>
							<div class="col-md-6">
								<?php echo Form::text('name'); ?>

							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">Address</label>
							<div class="col-md-6">
								<?php echo Form::text('address'); ?>

							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">City</label>
							<div class="col-md-6">
								<?php echo Form::text('city'); ?>

							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">State</label>
							<div class="col-md-6">
								<?php echo Form::text('state'); ?>

							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">Zip</label>
							<div class="col-md-6">
								<?php echo Form::text('zip'); ?>

							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">Average Rating(Optional)</label>
							<div class="col-md-6">
								<?php echo Form::text('avgrating'); ?>

							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">Website(Optional)</label>
							<div class="col-md-6">
								<?php echo Form::text('website'); ?>

							</div>
						</div>

					<?php echo Form::submit('Add Restaurant'); ?>


			<?php echo Form::close(); ?>

				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>