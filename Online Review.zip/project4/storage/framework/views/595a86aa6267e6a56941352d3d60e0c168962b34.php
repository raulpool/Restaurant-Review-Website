<?php $__env->startSection('content'); ?>
   <h1>Menu of all restaurants</h1>

<?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $got): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php if($got -> rid == 1): ?>
   <h4> <?php echo e($got->item_name); ?> Big Load For Matt </h4>
   <br>
   <strong>Price: </strong> <p> $ <?php echo e($got->price); ?></p>
   <br>
   <strong>Description: </strong> <p> <?php echo e($got -> description); ?></p>
   <br>
   <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>