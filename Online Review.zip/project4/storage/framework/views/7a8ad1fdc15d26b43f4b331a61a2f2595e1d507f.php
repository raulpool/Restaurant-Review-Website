<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $got): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php if($got->u_id == $userid): ?>
   <h1>Reviews for <?php echo e($got->name); ?></h1>
   <br>

<div class="btn-group">
    <a href="/project4/public/myreviewscont" class="btn btn-primary">
        <i class="fa fa-cog" aria-hidden="false"></i> Take me my reviews
    </a>
</div>
	<?php else: ?>
	<p>You don't have any reviews</p>

<?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>