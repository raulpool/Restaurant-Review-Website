<?php $__env->startSection('content'); ?>
   <p>You can add an item to your cart on this page</p>

<div class="btn-group">
    <a href="/project4/public/restaurantlist" class="btn btn-primary">
        <i class="fa fa-cog" aria-hidden="false"></i> Take me to the stores
    </a>
</div>

<?php echo Form::open(['url' => url('cart/additem')]); ?>


<?php echo Form::text('username'); ?>

<?php echo Form::password('password'); ?>

<?php echo Form::textarea('comments'); ?>

<?php echo Form::select('choice', ['one' => 'Choice One', 'two' => 'Choice Two']); ?>

<?php echo Form::submit('Submit Form'); ?>


<?php echo Form::close(); ?>


<?php for($i = 0; $i < 10; $i++): ?>
   <p>This is iteration <?php echo e($i); ?> of the loop</p>
<?php endfor; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>